package com.ars.test;

import static org.junit.Assert.*;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import com.ars.dao.ArsDaoImpl;
import com.ars.dao.IArsDao;
import com.ars.exception.ARSException;



public class TestArs {
	
	/**
	 * 
	 */
	
	static IArsDao fdao;
	
   @BeforeClass
	public static void setUpBeforeClass() throws Exception {
		 fdao=new ArsDaoImpl();
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		fdao=null;
	}
	
	/**
	 * 
	 */
	
	@Test
	public void testViewAllFlights() {
		try {
		
			assertNotNull(fdao.viewFlights("Mumbai","Chennai"));
			
		} catch (ARSException e) {
			e.getMessage();
		
		}
	}
	
	@Test
	public void testViewAllFlights1() {
		try {
		
			assertNull(fdao.viewFlights("Mumbai","Chennai"));
			
		} catch (ARSException e) {
			e.getMessage();
		
		}
	}
	
	@Test
	public void testDisplayBooking() {
		try {
		
			assertNotNull(fdao.displayBooking("101"));
			
		} catch (ARSException e) {
			
			e.getMessage();
		}
	}
	
	@Test
	public void testDisplayBooking1() {
		try {
		
			assertNull(fdao.displayBooking("101"));
			
		} catch (ARSException e) {
			
			e.getMessage();
		}
	}
	
	@Test
	public void testUpdateBooking() {
		try {
		
			assertNotNull(fdao.updateBooking("101","ars@g.com"));
			
		} catch (ARSException e) {
			
			e.getMessage();
		}
	}
	
	@Test
	public void testUpdateBooking1() {
		try {
		
			assertNull(fdao.updateBooking("101","ars@g.com"));
			
		} catch (ARSException e) {
			
			e.getMessage();
		}
	}
	
	
	
	@Test
	public void testdisplayBooking() {
		try {
		
			assertNotNull(fdao.displayBooking("102"));
			
		} catch (ARSException e) {
			
			e.getMessage();
		}
	}
	
	@Test
	public void testdisplayBooking1() {
		try {
		
			assertNull(fdao.displayBooking("102"));
			
		} catch (ARSException e) {
			
			e.getMessage();
		}
	}
	
	
}

package com.ars.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.ars.bean.BookingInformationBean;
import com.ars.bean.FlightInformationBean;
import com.ars.exception.ARSException;


@Repository
@Transactional
public class ArsDaoImpl implements IArsDao {

	@PersistenceContext
	EntityManager entityManager;
	
	/**
	 * 
	 *
	 */	
	
	public EntityManager getEntityManager() {
		return entityManager;
	}

	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}
	
	
	/*******************************************************************************************************
	 - Function Name	:	confirmBooking()
	 - Input Parameters	:   bookingInformation
	 - Return Type		:	bookingInformation bean
	 - Throws		    :   ARSException
	 - Author		    :   ARS Team
	 - Creation Date	:	24/12/2017
	 - Description		:	booking tickets
********************************************************************************************************/

	
	@Override
	public BookingInformationBean confirmBooking(
			BookingInformationBean bookingInformationBean) throws ARSException {
		BookingInformationBean bean=new BookingInformationBean();
		try {

			
			FlightInformationBean fbean=entityManager.find(FlightInformationBean.class, bookingInformationBean.getFlightNumber());
			bean.setClassType(bookingInformationBean.getClassType());
			bean.setCreditCardInformation(bookingInformationBean.getCreditCardInformation());
			bean.setCustomerEmail(bookingInformationBean.getCustomerEmail());
			bean.setDestinationCity(fbean.getArrivalCity());
			bean.setFlightNumber(bookingInformationBean.getFlightNumber());
			int numberOfPassengers=bookingInformationBean.getNumberOfPassengers();
			bean.setNumberOfPassengers(numberOfPassengers);
			
			bean.setSourceCity(fbean.getDepartureCity());
		

		
			if (bookingInformationBean.getClassType().equalsIgnoreCase("firstclass")) {
				
				String seatNumbers="";
				int firstSeats=fbean.getFirstClassSeats()-bookingInformationBean.getNumberOfPassengers();
				if (firstSeats>=0) {
					bean.setTotalFare(bookingInformationBean.getNumberOfPassengers()*fbean.getFirstClassSeatFare());
					int fseats=fbean.getFirstClassSeats();
					for (int i = 0; i < numberOfPassengers; i++) {
						
						seatNumbers=String.valueOf(fseats)+" "+seatNumbers;
						--fseats;
					}
					fbean.setFirstClassSeats(firstSeats);
					bean.setSeatNumbers(seatNumbers);
					
				}
				else{
					return null;
		
				}
				
			} 
			
			
			else {
				
				String seatNumbers="";
				int bussSeats=fbean.getBussinessClassSeats()-bookingInformationBean.getNumberOfPassengers();
				if (bussSeats>=0) {
					bean.setTotalFare(bookingInformationBean.getNumberOfPassengers()*fbean.getBussinessClassSeatsFare());
					int bseats=fbean.getBussinessClassSeats();
					for (int i = 0; i < numberOfPassengers; i++) {
						
						seatNumbers=String.valueOf(bseats)+" "+seatNumbers;
						--bseats;
					}
					fbean.setBussinessClassSeats(bussSeats);
					bean.setSeatNumbers(seatNumbers);
					
				}
				else{
					return null;
					//throw new ARSException("No Business class seats available \n Please try again");
				}
			}
			
			Query query =entityManager.createNativeQuery("Select bookingId_sequence.NEXTVAL from dual");
			bean.setBookingId(String.valueOf(query.getSingleResult()));
			

			entityManager.persist(bean);
			entityManager.merge(fbean);
			entityManager.flush();
			
		} catch (Exception e) {

			throw new ARSException("Exception in confirmBooking() in dao layer "+e.getMessage());
		}
		
		return bean;
	}
	
	/*******************************************************************************************************
	 - Function Name	:	displayBooking()
	 - Input Parameters	:   bookingId
	 - Return Type		:	bookingInformation bean
	 - Throws		    :   ARSException
	 - Author		    :   ARS Team
	 - Creation Date	:	24/12/2017
	 - Description		:	display tickets
********************************************************************************************************/

	@Override
	public BookingInformationBean displayBooking(String bookingId)
			throws ARSException {

		BookingInformationBean bean=null;
		try {
			bean = entityManager.find(BookingInformationBean.class, bookingId);
		} catch (Exception e) {
			throw new ARSException("Exception in displayBooking() in dao layer "+e.getMessage());
		}
		
		return bean;
	}

	/*******************************************************************************************************
	 - Function Name	:	cancelBooking()
	 - Input Parameters	:   bookingId
	 - Return Type		:	BookingInformationBean
	 - Throws		    :   ARSException
	 - Author		    :   ARS Team
	 - Creation Date	:	26/12/2017
	 - Description		:	Cancel a Ticket
********************************************************************************************************/

	
	@Override
	public BookingInformationBean cancelBooking(String bookingId)
			throws ARSException {
		System.out.println("bookingid in cb() "+bookingId);
		BookingInformationBean bean= entityManager.find(BookingInformationBean.class, bookingId);
		FlightInformationBean fbean= entityManager.find(FlightInformationBean.class, bean.getFlightNumber());
		System.out.println("in dao cb() bean value"+bean);
		System.out.println("in dao cb() fbean value"+fbean);
		try {
			
			if(bean!=null)
			{	
				entityManager.remove(bean);
				if(bean.getClassType().equalsIgnoreCase("firstclass"))
				{	
					int firstClassSeats=bean.getNumberOfPassengers()+fbean.getFirstClassSeats();
					fbean.setFirstClassSeats(firstClassSeats);
					fbean.setFirstClassSeats(firstClassSeats);
					fbean.setFirstClassSeats(firstClassSeats);
					System.out.println("first seats in cb() "+firstClassSeats);
				}
				else
				{
					int bussClassSeats=bean.getNumberOfPassengers()+fbean.getBussinessClassSeats();
					fbean.setBussinessClassSeats(bussClassSeats);
					fbean.setBussinessClassSeats(bussClassSeats);
					fbean.setBussinessClassSeats(bussClassSeats);
					System.out.println("buss seats in cb() "+bussClassSeats);
				}
				System.out.println("Before merge "+fbean);
				entityManager.merge(fbean);
				System.out.println("After merge "+fbean);
				entityManager.flush();
				
			}
		} catch (Exception e) {
			throw new ARSException("Exception in cancelBooking() in dao layer "+e.getMessage() );
		}
		return bean;
	}



	/*******************************************************************************************************
	 - Function Name	:	updateBooking()
	 - Input Parameters	:   bookingId,cust_email
	 - Return Type		:	BookingInformationBean
	 - Throws		    :   ARSException
	 - Author		    :   ARS Team
	 - Creation Date	:	26/12/2017
	 - Description		:	update booking information
********************************************************************************************************/
	
	
	@Override
	public BookingInformationBean updateBooking(String bookingId,
			String cust_email) throws ARSException {
		try {
			BookingInformationBean bean = entityManager.find(BookingInformationBean.class, bookingId);
			if(bean!=null)
			{
				bean.setCustomerEmail(cust_email);
				entityManager.merge(bean);
				entityManager.flush();
				return bean;
			}
		} catch (Exception e) {
			throw new ARSException("Exception in updateBooking() in dao layer "+e.getMessage() );
		}
		return null;
	}

	/*******************************************************************************************************
	 - Function Name	:	viewFlights()
	 - Input Parameters	:   source,destination
	 - Return Type		:	List of all flights
	 - Throws		    :   ARSException
	 - Author		    :   ARS Team
	 - Creation Date	:	24/12/2017
	 - Description		:	view flight information between source and destination
********************************************************************************************************/

	

	@Override
	public List<FlightInformationBean> viewFlights(String Source,
			String destination) throws ARSException {
		List<FlightInformationBean> list =null;
		try {
			TypedQuery<FlightInformationBean> qry = entityManager.createQuery("from FlightInformationBean where departureCity=:Source and arrivalCity=:destination", FlightInformationBean.class);
			qry.setParameter("Source", Source);
			qry.setParameter("destination", destination);
			list = qry.getResultList();
		} catch (Exception e) {
			throw new ARSException("Exception in viewFlights() in dao layer "+e.getMessage() );
		}
		
		return list;
	}
	

	/*******************************************************************************************************
	 - Function Name	:	viewFlight()
	 - Input Parameters	:   flightNumber
	 - Return Type		:	FlightInformationBean
	 - Throws		    :   ARSException
	 - Author		    :   ARS Team
	 - Creation Date	:	24/12/2017
	 - Description		:	view particular flight information
********************************************************************************************************/

	
	@Override
	public FlightInformationBean viewFlight(String flightNumber)
			throws ARSException {
		try {
			FlightInformationBean fbean=entityManager.find(FlightInformationBean.class, flightNumber);
			if(fbean!=null)
			{
				return fbean;
			}
		} catch (Exception e) {
			throw new ARSException("Exception in viewFlight() in dao layer "+e.getMessage() );
		}
		return null;
	}

}
